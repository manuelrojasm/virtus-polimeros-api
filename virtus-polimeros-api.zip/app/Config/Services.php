<?php

namespace Config;

use CodeIgniter\Config\BaseService;

/**
 * Services Configuration file.
 *
 * Services are simply other classes/libraries that the system uses
 * to do its job. This is used by CodeIgniter to allow the core of the
 * framework to be swapped out easily without affecting the usage within
 * the rest of your application.
 *
 * This file holds any application-specific services, or service overrides
 * that you might need. An example has been included with the general
 * method format you should use for your service methods. For more examples,
 * see the core Services file at system/Config/Services.php.
 */
class Services extends BaseService
{
    /**
     * Servicio de creación y validación de cursos (incluye creación de carpeta en servidor).
     */
    public static function curso($getShared = true)
    {
        if ($getShared) {
            return static::getSharedInstance('curso');
        }

        return new \App\Services\CursoService();
    }

    /**
     * Servicio de secciones de curso (crear secciones con archivos PDF en la carpeta del curso).
     */
    public static function seccionCurso($getShared = true)
    {
        if ($getShared) {
            return static::getSharedInstance('seccionCurso');
        }

        return new \App\Services\SeccionCursoService();
    }

    /**
     * Servicio de preguntas sugeridas por PDF (OpenAI). Requiere OPENAI_API_KEY en .env.
     */
    public static function preguntasSugeridas($getShared = true)
    {
        if ($getShared) {
            return static::getSharedInstance('preguntasSugeridas');
        }

        return new \App\Services\PreguntasSugeridasService();
    }

    /**
     * Subida de imágenes públicas (perfil, portadas) con límite de tamaño y tipos permitidos.
     */
    public static function imageUpload($getShared = true)
    {
        if ($getShared) {
            return static::getSharedInstance('imageUpload');
        }

        return new \App\Services\ImageUploadService();
    }

    /**
     * Servicio de desarrollo del curso por estudiante (inicio y finalización).
     */
    public static function cursoDesarrollo($getShared = true)
    {
        if ($getShared) {
            return static::getSharedInstance('cursoDesarrollo');
        }

        return new \App\Services\CursoDesarrolloService();
    }
}
